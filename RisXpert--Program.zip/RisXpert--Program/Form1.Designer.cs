﻿namespace RisXpert_App
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txtID = new System.Windows.Forms.TextBox();
            this.lblIDF1 = new System.Windows.Forms.Label();
            this.dtgvFase1 = new System.Windows.Forms.DataGridView();
            this.lblActive = new System.Windows.Forms.Label();
            this.txtActive = new System.Windows.Forms.TextBox();
            this.lblAnalyst = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblSave = new System.Windows.Forms.Label();
            this.lblNewRisk = new System.Windows.Forms.Label();
            this.txtAnalystName = new System.Windows.Forms.TextBox();
            this.btnSave1 = new System.Windows.Forms.Button();
            this.btnNewRisk = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lblID = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblCaseID2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dtgvFase2 = new System.Windows.Forms.DataGridView();
            this.btnSave2 = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dtgvFase3 = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dtgvFase4 = new System.Windows.Forms.DataGridView();
            this.tabControl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvFase1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvFase2)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvFase3)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvFase4)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage2);
            this.tabControl.Controls.Add(this.tabPage3);
            this.tabControl.Controls.Add(this.tabPage4);
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl.Font = new System.Drawing.Font("Century Schoolbook", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl.Location = new System.Drawing.Point(0, 0);
            this.tabControl.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(1217, 565);
            this.tabControl.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl.TabIndex = 0;
            this.tabControl.Selected += new System.Windows.Forms.TabControlEventHandler(this.tabControl_Selected);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.Window;
            this.tabPage1.Controls.Add(this.txtID);
            this.tabPage1.Controls.Add(this.lblIDF1);
            this.tabPage1.Controls.Add(this.dtgvFase1);
            this.tabPage1.Controls.Add(this.lblActive);
            this.tabPage1.Controls.Add(this.txtActive);
            this.tabPage1.Controls.Add(this.lblAnalyst);
            this.tabPage1.Controls.Add(this.lblDate);
            this.tabPage1.Controls.Add(this.lblSave);
            this.tabPage1.Controls.Add(this.lblNewRisk);
            this.tabPage1.Controls.Add(this.txtAnalystName);
            this.tabPage1.Controls.Add(this.btnSave1);
            this.tabPage1.Controls.Add(this.btnNewRisk);
            this.tabPage1.Location = new System.Drawing.Point(4, 28);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Size = new System.Drawing.Size(1209, 533);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Fase #1";
            // 
            // txtID
            // 
            this.txtID.BackColor = System.Drawing.SystemColors.Control;
            this.txtID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.txtID.Location = new System.Drawing.Point(987, 119);
            this.txtID.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(95, 17);
            this.txtID.TabIndex = 20;
            this.txtID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblIDF1
            // 
            this.lblIDF1.AutoSize = true;
            this.lblIDF1.ForeColor = System.Drawing.Color.Orange;
            this.lblIDF1.Location = new System.Drawing.Point(873, 119);
            this.lblIDF1.Name = "lblIDF1";
            this.lblIDF1.Size = new System.Drawing.Size(73, 19);
            this.lblIDF1.TabIndex = 15;
            this.lblIDF1.Text = "Case ID:";
            // 
            // dtgvFase1
            // 
            this.dtgvFase1.AllowUserToAddRows = false;
            this.dtgvFase1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvFase1.BackgroundColor = System.Drawing.SystemColors.Info;
            this.dtgvFase1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvFase1.Location = new System.Drawing.Point(3, 208);
            this.dtgvFase1.Name = "dtgvFase1";
            this.dtgvFase1.RowHeadersWidth = 51;
            this.dtgvFase1.RowTemplate.Height = 28;
            this.dtgvFase1.Size = new System.Drawing.Size(1203, 317);
            this.dtgvFase1.TabIndex = 19;
            this.dtgvFase1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvFase1_CellContentClick);
            // 
            // lblActive
            // 
            this.lblActive.AutoSize = true;
            this.lblActive.Location = new System.Drawing.Point(125, 175);
            this.lblActive.Name = "lblActive";
            this.lblActive.Size = new System.Drawing.Size(113, 19);
            this.lblActive.TabIndex = 18;
            this.lblActive.Text = "Bien o Activo:";
            this.lblActive.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtActive
            // 
            this.txtActive.BackColor = System.Drawing.SystemColors.Control;
            this.txtActive.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtActive.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.txtActive.Location = new System.Drawing.Point(243, 175);
            this.txtActive.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtActive.Name = "txtActive";
            this.txtActive.Size = new System.Drawing.Size(470, 17);
            this.txtActive.TabIndex = 17;
            this.txtActive.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtActive.TextChanged += new System.EventHandler(this.UpdateData);
            // 
            // lblAnalyst
            // 
            this.lblAnalyst.AutoSize = true;
            this.lblAnalyst.Location = new System.Drawing.Point(143, 132);
            this.lblAnalyst.Name = "lblAnalyst";
            this.lblAnalyst.Size = new System.Drawing.Size(111, 19);
            this.lblAnalyst.TabIndex = 16;
            this.lblAnalyst.Text = "Analista:        ";
            this.lblAnalyst.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.BackColor = System.Drawing.SystemColors.ControlLight;
            this.lblDate.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lblDate.Location = new System.Drawing.Point(1095, 35);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(0, 19);
            this.lblDate.TabIndex = 15;
            // 
            // lblSave
            // 
            this.lblSave.AutoSize = true;
            this.lblSave.Location = new System.Drawing.Point(136, 81);
            this.lblSave.Name = "lblSave";
            this.lblSave.Size = new System.Drawing.Size(126, 19);
            this.lblSave.TabIndex = 13;
            this.lblSave.Text = "Guardar Datos";
            // 
            // lblNewRisk
            // 
            this.lblNewRisk.AutoSize = true;
            this.lblNewRisk.Location = new System.Drawing.Point(136, 24);
            this.lblNewRisk.Name = "lblNewRisk";
            this.lblNewRisk.Size = new System.Drawing.Size(112, 19);
            this.lblNewRisk.TabIndex = 12;
            this.lblNewRisk.Text = "Nuevo Riesgo";
            // 
            // txtAnalystName
            // 
            this.txtAnalystName.BackColor = System.Drawing.SystemColors.Control;
            this.txtAnalystName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAnalystName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.txtAnalystName.Location = new System.Drawing.Point(243, 132);
            this.txtAnalystName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtAnalystName.Name = "txtAnalystName";
            this.txtAnalystName.Size = new System.Drawing.Size(470, 17);
            this.txtAnalystName.TabIndex = 8;
            this.txtAnalystName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtAnalystName.TextChanged += new System.EventHandler(this.UpdateData);
            // 
            // btnSave1
            // 
            this.btnSave1.Location = new System.Drawing.Point(62, 66);
            this.btnSave1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSave1.Name = "btnSave1";
            this.btnSave1.Size = new System.Drawing.Size(50, 50);
            this.btnSave1.TabIndex = 1;
            this.btnSave1.Text = "✔";
            this.btnSave1.UseVisualStyleBackColor = true;
            // 
            // btnNewRisk
            // 
            this.btnNewRisk.Location = new System.Drawing.Point(62, 8);
            this.btnNewRisk.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnNewRisk.Name = "btnNewRisk";
            this.btnNewRisk.Size = new System.Drawing.Size(50, 50);
            this.btnNewRisk.TabIndex = 0;
            this.btnNewRisk.Text = "➕";
            this.btnNewRisk.UseVisualStyleBackColor = true;
            this.btnNewRisk.Click += new System.EventHandler(this.btnNewRisk_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.Window;
            this.tabPage2.Controls.Add(this.lblID);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.lblCaseID2);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.dtgvFase2);
            this.tabPage2.Controls.Add(this.btnSave2);
            this.tabPage2.Location = new System.Drawing.Point(4, 28);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage2.Size = new System.Drawing.Size(1209, 533);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Fase #2";
            // 
            // lblID
            // 
            this.lblID.ForeColor = System.Drawing.Color.Red;
            this.lblID.Location = new System.Drawing.Point(1197, 65);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(112, 29);
            this.lblID.TabIndex = 18;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label3.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label3.Location = new System.Drawing.Point(1108, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 19);
            this.label3.TabIndex = 15;
            // 
            // lblCaseID2
            // 
            this.lblCaseID2.AutoSize = true;
            this.lblCaseID2.ForeColor = System.Drawing.Color.Orange;
            this.lblCaseID2.Location = new System.Drawing.Point(536, 138);
            this.lblCaseID2.Name = "lblCaseID2";
            this.lblCaseID2.Size = new System.Drawing.Size(73, 19);
            this.lblCaseID2.TabIndex = 14;
            this.lblCaseID2.Text = "Case ID:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(73, 138);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(126, 19);
            this.label5.TabIndex = 13;
            this.label5.Text = "Guardar Datos";
            // 
            // dtgvFase2
            // 
            this.dtgvFase2.AllowUserToAddRows = false;
            this.dtgvFase2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvFase2.BackgroundColor = System.Drawing.SystemColors.Info;
            this.dtgvFase2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvFase2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dtgvFase2.Location = new System.Drawing.Point(3, 199);
            this.dtgvFase2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dtgvFase2.Name = "dtgvFase2";
            this.dtgvFase2.RowHeadersWidth = 51;
            this.dtgvFase2.RowTemplate.Height = 24;
            this.dtgvFase2.Size = new System.Drawing.Size(1203, 330);
            this.dtgvFase2.TabIndex = 4;
            this.dtgvFase2.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvFase2_CellEndEdit);
            this.dtgvFase2.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.dgtvValues_CellValidating);
            // 
            // btnSave2
            // 
            this.btnSave2.Location = new System.Drawing.Point(8, 122);
            this.btnSave2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSave2.Name = "btnSave2";
            this.btnSave2.Size = new System.Drawing.Size(50, 50);
            this.btnSave2.TabIndex = 1;
            this.btnSave2.Text = "✔";
            this.btnSave2.UseVisualStyleBackColor = true;
            this.btnSave2.Click += new System.EventHandler(this.btnSave2_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dtgvFase3);
            this.tabPage3.Location = new System.Drawing.Point(4, 28);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1209, 533);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Fase #3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dtgvFase3
            // 
            this.dtgvFase3.AllowUserToAddRows = false;
            this.dtgvFase3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvFase3.BackgroundColor = System.Drawing.SystemColors.Info;
            this.dtgvFase3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvFase3.Location = new System.Drawing.Point(3, 95);
            this.dtgvFase3.Name = "dtgvFase3";
            this.dtgvFase3.RowHeadersWidth = 51;
            this.dtgvFase3.RowTemplate.Height = 24;
            this.dtgvFase3.Size = new System.Drawing.Size(1203, 435);
            this.dtgvFase3.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.dtgvFase4);
            this.tabPage4.Location = new System.Drawing.Point(4, 28);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1209, 533);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Fase #4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // dtgvFase4
            // 
            this.dtgvFase4.AllowUserToAddRows = false;
            this.dtgvFase4.AllowUserToDeleteRows = false;
            this.dtgvFase4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvFase4.BackgroundColor = System.Drawing.SystemColors.Info;
            this.dtgvFase4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvFase4.Location = new System.Drawing.Point(3, 95);
            this.dtgvFase4.Name = "dtgvFase4";
            this.dtgvFase4.ReadOnly = true;
            this.dtgvFase4.RowHeadersWidth = 51;
            this.dtgvFase4.RowTemplate.Height = 24;
            this.dtgvFase4.Size = new System.Drawing.Size(1203, 435);
            this.dtgvFase4.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1217, 565);
            this.Controls.Add(this.tabControl);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Text = "RisXpert";
            this.tabControl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvFase1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvFase2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvFase3)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvFase4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btnSave1;
        private System.Windows.Forms.Button btnNewRisk;
        private System.Windows.Forms.TextBox txtAnalystName;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblSave;
        private System.Windows.Forms.Label lblNewRisk;
        private System.Windows.Forms.Label lblAnalyst;
        private System.Windows.Forms.Label lblActive;
        private System.Windows.Forms.TextBox txtActive;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblCaseID2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dtgvFase2;
        private System.Windows.Forms.Button btnSave2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dtgvFase3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataGridView dtgvFase4;
        private System.Windows.Forms.DataGridView dtgvFase1;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.Label lblIDF1;
    }
}

